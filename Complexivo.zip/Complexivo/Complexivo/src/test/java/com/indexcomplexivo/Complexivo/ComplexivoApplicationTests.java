package com.indexcomplexivo.Complexivo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplexivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
