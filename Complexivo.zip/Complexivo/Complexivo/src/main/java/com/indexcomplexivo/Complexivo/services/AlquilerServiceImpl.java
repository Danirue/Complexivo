package com.indexcomplexivo.Complexivo.services;

import com.indexcomplexivo.Complexivo.models.AlquilerDisfraz;
import com.indexcomplexivo.Complexivo.repositories.BaseRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class AlquilerServiceImpl extends BaseServiceImpl<AlquilerDisfraz, Long> implements AlquilerService {
    public AlquilerServiceImpl(BaseRepository<AlquilerDisfraz, Long> baseRepository) {
        super(baseRepository);
    }

    @Override
    public List<AlquilerDisfraz> findAll() {
        return null;
    }

    @Override
    public Optional<AlquilerDisfraz> findById(Long aLong) {
        return Optional.empty();
    }

    @Override
    public void deleteById(Long aLong) {

    }

    @Override
    public List<AlquilerDisfraz> saveAll(List<AlquilerDisfraz> detalles) {
        return null;
    }

    @Override
    public AlquilerDisfraz save(AlquilerDisfraz entity) {
        return null;
    }
}
