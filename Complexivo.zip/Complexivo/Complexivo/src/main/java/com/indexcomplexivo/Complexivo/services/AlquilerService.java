package com.indexcomplexivo.Complexivo.services;

import com.indexcomplexivo.Complexivo.models.AlquilerDisfraz;

public interface AlquilerService extends BaseService<AlquilerDisfraz, Long>{
}
