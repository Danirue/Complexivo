package com.indexcomplexivo.Complexivo.services;

import com.indexcomplexivo.Complexivo.models.Cliente;

public interface ClienteService extends BaseService<Cliente, Long> {
    void update(Cliente cliente, Long id);
}
