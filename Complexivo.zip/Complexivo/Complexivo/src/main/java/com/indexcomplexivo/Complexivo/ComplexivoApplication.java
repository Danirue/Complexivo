package com.indexcomplexivo.Complexivo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplexivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplexivoApplication.class, args);
	}

}
