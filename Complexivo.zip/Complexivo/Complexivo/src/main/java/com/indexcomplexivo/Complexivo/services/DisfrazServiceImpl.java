package com.indexcomplexivo.Complexivo.services;

import com.indexcomplexivo.Complexivo.models.Disfraz;
import com.indexcomplexivo.Complexivo.repositories.BaseRepository;
import com.indexcomplexivo.Complexivo.repositories.DisfrazRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DisfrazServiceImpl extends BaseServiceImpl<Disfraz, Long> implements DisfrazService{
    @Autowired
    private DisfrazRepository repository;

    public DisfrazServiceImpl(BaseRepository<Disfraz, Long> baseRepository) {
        super(baseRepository);
    }
}
