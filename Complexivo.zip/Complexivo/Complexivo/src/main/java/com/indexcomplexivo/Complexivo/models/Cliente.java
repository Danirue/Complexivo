package com.indexcomplexivo.Complexivo.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "Cliente", uniqueConstraints = @UniqueConstraint(columnNames = "cedula_cliente"))
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_cliente;
    private String cedula_cliente;
    private String nombres_cliente;
    private String apellidos_cliente;
    private String direccion_cliente;
    private Boolean estado_cliente;

    @JsonIgnore
    @OneToMany(mappedBy = "cliente",cascade = CascadeType.ALL)
    private List<AlquilerDisfraz> alquilerDisfraz;

}
