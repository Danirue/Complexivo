package com.indexcomplexivo.Complexivo.repositories;

import com.indexcomplexivo.Complexivo.models.AlquilerDisfraz;
import com.indexcomplexivo.Complexivo.models.Disfraz;
import org.springframework.stereotype.Repository;

@Repository
public interface DisfrazRepository extends BaseRepository<Disfraz, Long>{
}
