package com.indexcomplexivo.Complexivo.repositories;

import com.indexcomplexivo.Complexivo.models.AlquilerDisfraz;
import org.springframework.stereotype.Repository;

@Repository
public interface AlquilerRepository extends BaseRepository<AlquilerDisfraz, Long>{
}
