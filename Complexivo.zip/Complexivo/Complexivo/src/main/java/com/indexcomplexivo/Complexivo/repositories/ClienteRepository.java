package com.indexcomplexivo.Complexivo.repositories;

import com.indexcomplexivo.Complexivo.models.AlquilerDisfraz;
import com.indexcomplexivo.Complexivo.models.Cliente;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends BaseRepository<Cliente, Long>{
}
