package com.indexcomplexivo.Complexivo.services;

import com.indexcomplexivo.Complexivo.models.Disfraz;

public interface DisfrazService extends BaseService<Disfraz, Long> {
}
