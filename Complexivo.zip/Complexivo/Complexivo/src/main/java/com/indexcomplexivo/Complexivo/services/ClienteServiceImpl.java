package com.indexcomplexivo.Complexivo.services;

import com.indexcomplexivo.Complexivo.models.Cliente;
import com.indexcomplexivo.Complexivo.repositories.BaseRepository;
import com.indexcomplexivo.Complexivo.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClienteServiceImpl extends BaseServiceImpl<Cliente, Long> implements ClienteService {
    @Autowired
    private ClienteRepository repository;

    public ClienteServiceImpl(BaseRepository<Cliente, Long> baseRepository) {
        super(baseRepository);
    }
}
