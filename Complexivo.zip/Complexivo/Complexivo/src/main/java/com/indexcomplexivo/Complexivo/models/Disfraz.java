package com.indexcomplexivo.Complexivo.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "Disfraz", uniqueConstraints = @UniqueConstraint(columnNames = "codigo_disfraz"))
public class Disfraz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_disfraz;
    private String codigo_disfraz;
    private String descripcion_disfraz;
    private Integer precio_alquiler;
    private String tipo_disfraz;

    @JsonIgnore
    @OneToMany(mappedBy = "disfraz",cascade = CascadeType.ALL)
    private List<AlquilerDisfraz> alquilerDisfraz;

}
