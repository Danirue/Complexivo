package com.indexcomplexivo.Complexivo.models;

import jakarta.persistence.*;
import lombok.Data;


import java.util.Date;

@Entity
@Data
@Table(name = "AlquilerDisfraz")
public class AlquilerDisfraz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_alquiler;
    @Temporal(TemporalType.DATE)
    private Date fecha_prestamo;
    @Temporal(TemporalType.DATE)
    private Date fecha_devoluciom;

    @ManyToOne
    @JoinColumn(name = "id_cliente")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "id_disfraz")
    private Disfraz disfraz;

}
