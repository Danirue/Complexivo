package com.indexcomplexivo.Complexivo.controllers;

import com.indexcomplexivo.Complexivo.models.Cliente;
import com.indexcomplexivo.Complexivo.services.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/api/cliente")
public class ClienteIndexController {

    @Autowired
    private ClienteService service;

    @GetMapping("/clientes")
    public ModelAndView listarClientes() {
        ModelAndView mav = new ModelAndView("clientForm");
        List<Cliente> clientes = service.findAll();
        mav.addObject("clientes", clientes);
        return mav;
    }


    @PostMapping({"/crear"})
    public ResponseEntity<?> crearCliente(Cliente cliente, Model model) {
        return ResponseEntity.ok(service.save(cliente));
    }

    @PostMapping("/editar/form/{id}")
    public String editar(@ModelAttribute("cliente") Cliente cliente, @PathVariable("id")Long id) {
        cliente.setId_cliente(id);
        service.update(cliente, id);
        return "redirect:/api/cliente/";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable("id") Long id) {
        service.deleteById(id);
        return "redirect:/api/cliente/";
    }

    @GetMapping("/editar/{id}")
    public String buscar(@PathVariable("id") Long id, Model m) {
        Cliente cliente = service.findById(id).orElse(null);
        m.addAttribute("cliente", cliente);
        return "editClient";
    }
}
